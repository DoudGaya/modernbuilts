

interface User {
 id: string 
 firstName: string
 
}