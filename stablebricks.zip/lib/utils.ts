import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}


export const generateReferralCode = (email: string) => {
  const rand = Math.random().toString(36).substring(7)
  return `${email.split('@')[0]}-${rand}`
} 


export const isProduction = process.env.NODE_ENV === "production"
export const isLocal = process.env.NODE_ENV === 'development'