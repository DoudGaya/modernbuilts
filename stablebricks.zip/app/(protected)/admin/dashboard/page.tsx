import React from 'react'

const page = () => {
  return (
    <div className=' bg-white dark:bg-black/90'>Admin Home</div>
  )
}

export default page