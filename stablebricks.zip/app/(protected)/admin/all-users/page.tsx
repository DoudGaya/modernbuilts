import React from 'react'

const page = () => {
  return (
    <div>All Users</div>
  )
}

export default page