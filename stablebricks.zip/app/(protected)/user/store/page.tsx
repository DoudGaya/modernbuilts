import React from 'react'

const page = () => {
  return (
    <div>Store</div>
  )
}

export default page