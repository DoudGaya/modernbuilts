import React from 'react'

const page = () => {
  return (
    <div>Sell Assets</div>
  )
}

export default page