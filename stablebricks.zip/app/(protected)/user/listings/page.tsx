import React from 'react'

const page = () => {
  return (
    <div>Listings</div>
  )
}

export default page