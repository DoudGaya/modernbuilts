import React from 'react'

const page = () => {
  return (
    <div>Consultation</div>
  )
}

export default page