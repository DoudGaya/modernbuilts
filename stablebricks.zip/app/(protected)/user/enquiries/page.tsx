import React from 'react'

const page = () => {
  return (
    <div>Enquiries</div>
  )
}

export default page