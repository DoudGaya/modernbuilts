import { ResetForm } from '@/components/auth/ResetForm'
import React from 'react'

const ForgotPassword = () => {
  return <ResetForm />
}

export default ForgotPassword
