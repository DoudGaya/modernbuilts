import React from 'react'
import { LoginForm } from '@/components/auth/LogInForm'

const page = () => {
  return <LoginForm />
}

export default page