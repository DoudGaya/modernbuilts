import { ErrorCard } from '@/components/auth/ErrorCard'
import React from 'react'

const AuthErrorPage  = () => {
  return <ErrorCard />
}

export default AuthErrorPage