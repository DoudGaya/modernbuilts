import React from 'react'
import { SignUpForm } from '@/components/auth/signUpForm'
const page = () => {
  return <SignUpForm />
}
export default page