import React from 'react'
import { NewPasswordForm } from '@/components/auth/NewPasswordForm'

const page = () => {
  return (
    <div>
        <NewPasswordForm />
    </div>
  )
}

export default page