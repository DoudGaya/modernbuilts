import React from 'react'

export const ErrorCard = () => {
  return (
    <div>
        Hello Error
    </div>
  )
}
