"use client"
import { useState, createContext, useContext } from "react"

const profileContext = createContext('')

export default profileContext


